# Bid/No-Bid Decision Record

> Confirm the correct FWF FOR-series code for this form against the Drive bid
> library before adopting as the standard template.

**Date:** {date}
**Opportunity:** {title}
**Buyer:** {buyer}
**Reference / OCID:** {reference}
**Route to market:** {route}
**Value / duration:** {value} / {duration}
**Submission deadline:** {deadline}
**Clarification window closes:** {clarification_deadline}

---

## Hard gates

| Gate | Result | Reason |
|------|--------|--------|
| G1 Route to market | {G1} | {G1_reason} |
| G2 Financial standing (EFS/FVRA) | {G2} | {G2_reason} |
| G3 Capability fit | {G3} | {G3_reason} |
| G4 Deliverability | {G4} | {G4_reason} |
| G5 Deadline feasibility | {G5} | {G5_reason} |
| G6 Eligibility & mandatory reqs | {G6} | {G6_reason} |

## Weighted score

| Dimension | Score (1-5) | Weight | Contribution |
|-----------|-------------|--------|--------------|
| Strategic fit | {s1} | 20% | {c1} |
| Win probability | {s2} | 30% | {c2} |
| Commercial value | {s3} | 20% | {c3} |
| Deliverability & risk | {s4} | 20% | {c4} |
| Effort-to-win ratio | {s5} | 10% | {c5} |
| **Weighted total** | | | **{total}** |

## Recommendation

**{recommendation}** — {decisive_factor}

**Conditions to resolve (if CONDITIONAL):**
- {condition} — by {condition_deadline} — owner: {condition_owner}

---

## MD decision

**Decision:** GO / NO-GO
**Date:** {decision_date}
**By:** {md}
**Rationale:** {rationale}

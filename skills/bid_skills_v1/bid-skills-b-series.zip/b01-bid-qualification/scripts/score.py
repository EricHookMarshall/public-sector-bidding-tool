#!/usr/bin/env python3
"""B01 — Bid Qualification scoring engine.

Deterministic. Applies the two-layer model:
  Layer 1: hard gates (any FAIL forces NO-BID; CONDITIONAL flags a condition)
  Layer 2: weighted 1-5 score across five dimensions -> recommendation band

Usage (as a module):
    from score import qualify
    result = qualify(gates, scores)          # dicts, see below

Usage (CLI, JSON in / JSON out):
    python score.py --json '{"gates": {...}, "scores": {...}}'

Gate values: "PASS" | "FAIL" | "CONDITIONAL"
Gate keys:   G1 route, G2 efs, G3 capability, G4 deliverability,
             G5 deadline, G6 eligibility
Score keys:  strategic_fit, win_probability, commercial_value,
             deliverability_risk, effort_ratio   (each 1-5)
"""
import argparse
import json
import sys

# Default dimension weights (must sum to 1.0). Adjustable — see SKILL.md.
WEIGHTS = {
    "strategic_fit": 0.20,
    "win_probability": 0.30,
    "commercial_value": 0.20,
    "deliverability_risk": 0.20,
    "effort_ratio": 0.10,
}

GATE_KEYS = ["G1", "G2", "G3", "G4", "G5", "G6"]


def _band(score, conditional):
    if score >= 3.7:
        return "CONDITIONAL BID" if conditional else "BID"
    if score >= 3.0:
        return "REVIEW"
    return "NO-BID"


def qualify(gates, scores, weights=None):
    weights = weights or WEIGHTS
    if abs(sum(weights.values()) - 1.0) > 1e-6:
        raise ValueError("Weights must sum to 1.0 (100%).")

    # ---- Layer 1: hard gates ----
    failed = [k for k in GATE_KEYS if gates.get(k, "").upper() == "FAIL"]
    conditional = [k for k in GATE_KEYS if gates.get(k, "").upper() == "CONDITIONAL"]
    if failed:
        return {
            "recommendation": "NO-BID",
            "reason": f"Hard gate failure: {', '.join(failed)}",
            "gates_failed": failed,
            "scored": False,
        }

    # ---- Layer 2: weighted score ----
    for dim in weights:
        v = scores.get(dim)
        if v is None or not (1 <= v <= 5):
            raise ValueError(f"Score for '{dim}' must be 1-5 (got {v!r}).")

    contributions = {d: round(scores[d] * w, 3) for d, w in weights.items()}
    total = round(sum(contributions.values()), 2)
    is_cond = bool(conditional)

    return {
        "recommendation": _band(total, is_cond),
        "weighted_score": total,
        "contributions": contributions,
        "gates_conditional": conditional,
        "conditional": is_cond,
        "scored": True,
    }


def main():
    ap = argparse.ArgumentParser(description="B01 bid qualification scorer")
    ap.add_argument("--json", help="JSON with keys 'gates' and 'scores'")
    args = ap.parse_args()
    if not args.json:
        ap.print_help()
        sys.exit(0)
    payload = json.loads(args.json)
    result = qualify(payload.get("gates", {}), payload.get("scores", {}),
                     payload.get("weights"))
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()

# Reuse-readiness rubric

Score every candidate prior answer into one band. Discard anything below Rework.

| Band | Meaning | Action |
|------|---------|--------|
| **Drop-in** | Directly answers this requirement; facts current; won or neutral outcome | Reuse with only client/date swap |
| **Light-edit** | Right topic and structure; some facts to refresh | Reuse, apply the freshness checks |
| **Rework** | Relevant material but needs restructuring to fit the question/limit | Use as raw material, largely rewrite |
| **Not usable** | Off-topic, badly out of date, or from a lost bid on this weakness | Discard; hand to B04 for net-new |

## Ranking inputs (in priority order)

1. **Relevance** — does it answer *this* requirement, at the right depth?
2. **Outcome** — content from won bids over lost; check the Bid Library Tracker.
3. **Recency** — newer content reflects the current Microsoft Practice offering
   (established Sept 2024) and current procurement regime.
4. **Evidenceability** — can the claims still be evidenced today?

## Mandatory freshness checks (apply to every reused answer)

- Framework / RM codes current (RM1557.15 vs .14; retire RM6263)
- Regime language current (PA23, not PCR 2015; MAT, not MEAT)
- Body name current (GCA, not CCS — renamed 1 April 2026)
- No former staff named as live contacts
- Figures, dates, certifications, insurance values current
- Word/character limit re-checked against *this* question's constraint

## Output format per candidate

```
Candidate: <source file>  (date, outcome)
Band: <Drop-in | Light-edit | Rework>
Reusable text: <the passage>
Edits required: <specific, itemised>
```

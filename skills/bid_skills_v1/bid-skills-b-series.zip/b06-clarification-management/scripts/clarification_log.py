#!/usr/bin/env python3
"""B06 — Clarification register.

Maintains a JSON register of clarification requests during a bid evaluation
period. Computes working days to deadline; flags due-soon and overdue items.

Commands:
    add    --register r.json --ref C1 --received 2026-07-08 --deadline 2026-07-15 --owner Eric --summary "parent co data"
    list   --register r.json
    close  --register r.json --ref C1 --sent 2026-07-12

The register is a plain JSON file — keep it in the bid folder, never in memory.
"""
import argparse
import json
import os
from datetime import date, datetime


def _load(path):
    if os.path.exists(path):
        with open(path) as f:
            return json.load(f)
    return {"items": []}


def _save(path, data):
    with open(path, "w") as f:
        json.dump(data, f, indent=2)


def _parse(d):
    return datetime.strptime(d, "%Y-%m-%d").date()


def working_days_between(a, b):
    """Working days from a to b inclusive of neither end; negative if b < a."""
    if b < a:
        return -working_days_between(b, a)
    days, cur = 0, a
    from datetime import timedelta
    while cur < b:
        cur += timedelta(days=1)
        if cur.weekday() < 5:  # Mon-Fri
            days += 1
    return days


def cmd_add(args):
    data = _load(args.register)
    if any(i["ref"] == args.ref for i in data["items"]):
        raise SystemExit(f"Ref {args.ref} already exists.")
    data["items"].append({
        "ref": args.ref,
        "received": args.received,
        "deadline": args.deadline,
        "owner": args.owner,
        "summary": args.summary,
        "status": "OPEN",
        "sent": None,
    })
    _save(args.register, data)
    print(f"Logged {args.ref} (deadline {args.deadline}, owner {args.owner}).")


def cmd_close(args):
    data = _load(args.register)
    for i in data["items"]:
        if i["ref"] == args.ref:
            i["status"] = "CLOSED"
            i["sent"] = args.sent
            _save(args.register, data)
            print(f"Closed {args.ref} (sent {args.sent}).")
            return
    raise SystemExit(f"Ref {args.ref} not found.")


def cmd_list(args):
    data = _load(args.register)
    today = date.today()
    open_items = [i for i in data["items"] if i["status"] == "OPEN"]
    if not open_items:
        print("No open clarifications.")
    for i in sorted(open_items, key=lambda x: x["deadline"] or "9999"):
        try:
            wd = working_days_between(today, _parse(i["deadline"]))
            if wd < 0:
                flag = f"OVERDUE by {-wd} working day(s) **"
            elif wd <= 2:
                flag = f"DUE SOON — {wd} working day(s) **"
            else:
                flag = f"{wd} working days left"
        except (ValueError, TypeError):
            flag = "DEADLINE UNKNOWN — chase buyer **"
        print(f"[{i['ref']}] {i['summary']}")
        print(f"    owner: {i['owner']}  deadline: {i['deadline']}  -> {flag}")
    closed = [i for i in data["items"] if i["status"] == "CLOSED"]
    if closed:
        print(f"\n({len(closed)} closed)")


def main():
    ap = argparse.ArgumentParser(description="B06 clarification register")
    sub = ap.add_subparsers(dest="cmd", required=True)

    a = sub.add_parser("add")
    a.add_argument("--register", required=True)
    a.add_argument("--ref", required=True)
    a.add_argument("--received", required=True)
    a.add_argument("--deadline", required=True)
    a.add_argument("--owner", required=True)
    a.add_argument("--summary", default="")
    a.set_defaults(func=cmd_add)

    c = sub.add_parser("close")
    c.add_argument("--register", required=True)
    c.add_argument("--ref", required=True)
    c.add_argument("--sent", required=True)
    c.set_defaults(func=cmd_close)

    l = sub.add_parser("list")
    l.add_argument("--register", required=True)
    l.set_defaults(func=cmd_list)

    args = ap.parse_args()
    args.func(args)


if __name__ == "__main__":
    main()

# Clarification monitoring — the discipline

The skill logs and drafts. It does not watch the inbox. These rules do the real
work, and they are what was missing when G-Cloud 15 failed.

## Non-negotiables

1. **Named owner + named backup** for the whole evaluation period. Ownership
   must not sit with anyone who could leave mid-window. (Both key departures in
   the G-Cloud 15 window left clarifications unowned — the root cause.)

2. **Monitored shared mailbox**, not an individual's inbox, as the portal /
   submission contact. Individual inboxes go dark when people leave. The
   G-Cloud 15 clarifications routed to a departed employee's inbox and sat
   unread for weeks.
   - Live action: the G-Cloud 14 Digital Marketplace listing still shows a
     former employee as contact — update it to a monitored address now.

3. **Daily check** of both the portal and the mailbox throughout evaluation.
   Portals do not always email; the portal itself must be checked.

4. **Assume short windows.** Clarification deadlines are typically 5–10 working
   days. Treat every request as urgent from the moment it lands.

## Cadence

| When | Action |
|------|--------|
| Before evaluation starts | Confirm owner, backup, and monitored mailbox (B05 hand-off). Create the register. |
| Daily during evaluation | Check portal + mailbox. Run `clarification_log.py list`. |
| On any request | Log immediately. Draft. Route for sign-off. Send well before deadline. |
| On send | Close the register entry with the sent date. |
| At award/standstill | Confirm no open items remain. |

## The one-line lesson

The G-Cloud 15 disregard was not a commercial weakness — the materials existed
and the fix was minor. It was an ownership-and-monitoring failure. Do not let a
clever skill stack disguise the fact that this step needs a person who is
watching.

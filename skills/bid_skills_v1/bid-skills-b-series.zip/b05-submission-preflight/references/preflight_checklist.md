# Submission pre-flight checklist

Nothing below can be waived by the skill. NOT READY stands until each is cleared.

## 1. Mandatory requirements
- [ ] Every Mandatory (M) row in the B02 matrix is **Green** (complete,
      reviewed, evidenced).
- [ ] No orphan answers (every answer maps to a matrix Ref).

## 2. Answer compliance
- [ ] Every answer within its word/character limit.
- [ ] No unfilled `[EVIDENCE: ...]` placeholders.
- [ ] Regime-correct language (PA23/MAT; correct RM codes; GCA not CCS).

## 3. Supporting documents (present and current)
- [ ] Employer's Liability insurance
- [ ] Public Liability insurance
- [ ] Professional Indemnity insurance
- [ ] Cyber cover
- [ ] Carbon Reduction Plan (where thresholds apply)
- [ ] Modern Slavery statement
- [ ] Pricing document
- [ ] Declarations (conflict of interest, exclusion grounds)

## 4. EFS / FVRA gate (BLOCKING)
Clears only if **one** is true and confirmed for *this* route:
- [ ] Route imposes no separate financial-standing stage (e.g. below-threshold
      under PA23), **or**
- [ ] FWF standalone position clears the stated threshold, **or**
- [ ] Arobs Group PCG is in place, current, and confirmed acceptable **at this
      stage of this procurement**.

> PCG acceptability at framework-application stage is not universal. Verify
> against the live instructions (e.g. RM1557.15 Attachment 5 FVRA) per bid.

## 5. Clarification handling (BLOCKING — the G-Cloud 15 lesson)
- [ ] A named owner is assigned for clarification correspondence for the whole
      evaluation period.
- [ ] The submission/clarification mailbox is confirmed monitored (not a former
      staff member's inbox).
- [ ] Handover to B06 (Clarification Management) is set up.

## 6. Logistics
- [ ] Correct portal, correct lot(s).
- [ ] Deadline (date **and** time, correct timezone) confirmed.
- [ ] Submission planned with buffer — not on the deadline itself.

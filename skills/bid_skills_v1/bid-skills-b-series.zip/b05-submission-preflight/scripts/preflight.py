#!/usr/bin/env python3
"""B05 — Submission pre-flight & EFS/FVRA gate engine.

Deterministic. Reads a bid config and returns READY / NOT READY plus an
itemised punch-list. The EFS gate and the clarification-owner check are
blocking and cannot be waived here.

Usage:
    python preflight.py --config bid.json

bid.json shape:
{
  "bid": "G-Cloud 15 Lot 3",
  "mandatory_rows": [                 # from the B02 matrix (M rows only)
    {"ref": "3.2.1", "status": "Green"},
    {"ref": "3.2.2", "status": "Amber"}
  ],
  "answers": [                        # optional per-answer compliance flags
    {"ref": "3.2.1", "within_limit": true, "placeholders": 0}
  ],
  "documents": {                      # present/current booleans
    "employers_liability": true, "public_liability": true,
    "professional_indemnity": true, "cyber_cover": true,
    "carbon_reduction_plan": true, "modern_slavery": true,
    "pricing": true, "declarations": true
  },
  "efs": {
    "route_has_financial_stage": true,
    "standalone_clears": false,
    "pcg_in_place": false,
    "pcg_acceptable_this_stage": false
  },
  "clarification_owner": "",          # named owner
  "clarification_mailbox_monitored": false
}
"""
import argparse
import json
import sys

REQUIRED_DOCS = [
    "employers_liability", "public_liability", "professional_indemnity",
    "cyber_cover", "carbon_reduction_plan", "modern_slavery",
    "pricing", "declarations",
]


def efs_cleared(efs):
    if not efs.get("route_has_financial_stage", True):
        return True, "Route imposes no separate financial-standing stage."
    if efs.get("standalone_clears"):
        return True, "Standalone accounts clear the threshold."
    if efs.get("pcg_in_place") and efs.get("pcg_acceptable_this_stage"):
        return True, "Arobs PCG in place and confirmed acceptable at this stage."
    return False, ("EFS gate NOT cleared: no PCG in place / acceptability "
                   "unconfirmed and standalone insufficient. This is the "
                   "G-Cloud 15 failure mode.")


def run(cfg):
    outstanding = {"mandatory_incomplete": [], "answers_noncompliant": [],
                   "documents_missing": [], "efs_gate": [],
                   "clarification": []}

    for row in cfg.get("mandatory_rows", []):
        if (row.get("status") or "").capitalize() != "Green":
            outstanding["mandatory_incomplete"].append(
                f"{row.get('ref')} ({row.get('status')})")

    for ans in cfg.get("answers", []):
        problems = []
        if ans.get("within_limit") is False:
            problems.append("over limit")
        if ans.get("placeholders", 0) > 0:
            problems.append(f"{ans['placeholders']} unfilled placeholder(s)")
        if problems:
            outstanding["answers_noncompliant"].append(
                f"{ans.get('ref')}: {', '.join(problems)}")

    docs = cfg.get("documents", {})
    for d in REQUIRED_DOCS:
        if not docs.get(d):
            outstanding["documents_missing"].append(d)

    ok, msg = efs_cleared(cfg.get("efs", {}))
    if not ok:
        outstanding["efs_gate"].append(msg)

    if not cfg.get("clarification_owner"):
        outstanding["clarification"].append("No clarification owner assigned.")
    if not cfg.get("clarification_mailbox_monitored"):
        outstanding["clarification"].append("Clarification mailbox not confirmed monitored.")

    any_outstanding = any(outstanding.values())
    return ("NOT READY" if any_outstanding else "READY"), outstanding


def main():
    ap = argparse.ArgumentParser(description="B05 submission pre-flight")
    ap.add_argument("--config", required=True, help="bid config JSON")
    args = ap.parse_args()
    cfg = json.load(open(args.config))

    verdict, outstanding = run(cfg)
    print(f"Bid: {cfg.get('bid', '(unnamed)')}")
    print(f"VERDICT: {verdict}\n")
    labels = {
        "mandatory_incomplete": "Mandatory rows not Green",
        "answers_noncompliant": "Answers non-compliant",
        "documents_missing": "Supporting documents missing/unconfirmed",
        "efs_gate": "EFS / FVRA gate",
        "clarification": "Clarification handling",
    }
    for key, label in labels.items():
        items = outstanding[key]
        if items:
            print(f"[{label}]")
            for it in items:
                print(f"  - {it}")
            print()
    sys.exit(0 if verdict == "READY" else 1)


if __name__ == "__main__":
    main()

# Answer patterns & framing

## Core structure — claim / evidence / benefit

Every substantive point:

1. **Claim** — what FWF does / will do (specific, active).
2. **Evidence** — how it is proven (metric, prior delivery, certification,
   named method). Use `[EVIDENCE: ...]` where a real fact must be inserted.
3. **Benefit** — what the buyer gets from it (outcome, risk reduced, value).

## Method answers — method / deliverable / assurance

For "describe your approach to X" questions:

1. **Method** — the actual steps/framework FWF uses.
2. **Deliverable** — the tangible output the buyer receives.
3. **Assurance** — how quality/timeline/risk is controlled.

## Win-theme framing

- Lead with the buyer's outcome, not FWF's history.
- Thread 2–3 consistent win themes through every answer (e.g. Microsoft-native
  delivery, low-risk adoption, measurable time-to-value).
- Mirror the evaluation criteria's language so scoring is effortless.

## FWF honesty guardrails

- FWF UK is a small team; Romanian delivery is recharged from Arobs. Frame
  delivery capacity honestly through the Arobs relationship — do not imply a
  large standalone UK bench.
- Stay inside the Microsoft Practice envelope (Power Platform, Copilot Studio,
  M365, Azure AI). Anything outside needs a named partner basis.
- No invented metrics, clients, or certifications. Placeholder, don't fabricate.
- Regime-correct: PA23 / MAT for new procurements; correct RM codes; GCA not CCS.

## Common failure modes to avoid

- Generic filler ("robust", "world-class", "synergies") with no substance.
- Answering a different (easier) question than the one asked.
- Overrunning the word/character limit.
- Claims with no evidence and no benefit.
- Copy-paste from an old bid without the freshness checks (see B03).

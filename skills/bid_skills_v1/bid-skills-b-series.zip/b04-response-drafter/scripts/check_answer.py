#!/usr/bin/env python3
"""B04 — Answer checker.

Deterministic checks on a drafted bid answer:
  1. Word / character count vs the stated limit (over-limit is a hard fail).
  2. Requirement-keyword coverage (did the answer address the key terms?).
  3. Unfilled [EVIDENCE: ...] placeholders (must be resolved before submission).

Usage:
    python check_answer.py --limit "500 words" --keywords "security,SLA,incident" --file draft.txt
    echo "draft text" | python check_answer.py --limit "1000 characters" --keywords "azure"
"""
import argparse
import re
import sys


def parse_limit(limit):
    """Return (kind, n) where kind is 'words' or 'chars', or (None, None)."""
    if not limit:
        return None, None
    m = re.search(r"(\d[\d,]*)", limit)
    if not m:
        return None, None
    n = int(m.group(1).replace(",", ""))
    kind = "chars" if re.search(r"char", limit, re.I) else "words"
    return kind, n


def main():
    ap = argparse.ArgumentParser(description="Check a drafted bid answer")
    ap.add_argument("--limit", default="", help='e.g. "500 words" or "2000 characters"')
    ap.add_argument("--keywords", default="", help="comma-separated requirement keywords")
    ap.add_argument("--file", help="draft file; if omitted, reads stdin")
    args = ap.parse_args()

    text = open(args.file).read() if args.file else sys.stdin.read()

    words = len(re.findall(r"\S+", text))
    chars = len(text)

    print(f"Word count: {words}")
    print(f"Character count: {chars}")

    kind, limit_n = parse_limit(args.limit)
    status_ok = True
    if kind:
        used = words if kind == "words" else chars
        pct = round(100 * used / limit_n) if limit_n else 0
        over = used > limit_n
        status_ok = status_ok and not over
        flag = "OVER LIMIT" if over else f"{pct}% of limit"
        print(f"Limit: {limit_n} {kind} -> {used} used ({flag})")
        if over:
            print("  ** FAIL: over the stated limit. Trim before submission. **")
    else:
        print("Limit: not parsed (none supplied or unrecognised format)")

    if args.keywords:
        kws = [k.strip() for k in args.keywords.split(",") if k.strip()]
        low = text.lower()
        missing = [k for k in kws if k.lower() not in low]
        covered = [k for k in kws if k.lower() in low]
        print(f"Keywords covered: {', '.join(covered) if covered else '(none)'}")
        if missing:
            status_ok = False
            print(f"  ** Missing keywords: {', '.join(missing)} — confirm the "
                  f"answer addresses these. **")

    placeholders = re.findall(r"\[EVIDENCE:[^\]]*\]", text)
    if placeholders:
        status_ok = False
        print(f"Unfilled evidence placeholders: {len(placeholders)} — resolve "
              f"before submission:")
        for p in placeholders:
            print(f"   {p}")

    print("RESULT:", "OK" if status_ok else "NEEDS ATTENTION")
    sys.exit(0 if status_ok else 1)


if __name__ == "__main__":
    main()

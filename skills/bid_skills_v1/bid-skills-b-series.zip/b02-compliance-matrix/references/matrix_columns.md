# Compliance Matrix — column definition

> Reconcile against the live G-Cloud 15 Compliance Matrix in Drive
> (`15TpOKNaR2bkJAyaTN3xc2hE7Kdq4EnyL`) before first live use, so this matches
> FWF's existing template exactly.

| Column | Purpose | Values |
|--------|---------|--------|
| Ref | Source clause / question number | verbatim from source |
| Requirement | The requirement text | faithful, concise |
| M/D | Mandatory or Desirable | M \| D |
| Response type | What kind of answer is needed | narrative \| evidence \| declaration \| pricing |
| Weighting | Evaluation weight if stated | e.g. 10% |
| Limit | Response constraint | e.g. 500 words / 2 pages |
| Lot | Which lot this belongs to | e.g. Lot 3 |
| Owner | Who drafts / provides evidence | name |
| Status | Progress RAG | Red \| Amber \| Green |
| Evidence source | Where FWF evidence lives | Drive link / doc ref |
| Notes | Anything else | free text |

## RAG convention

- **Red** — not started / no evidence identified (default on creation)
- **Amber** — drafted or evidence identified, not yet reviewed/complete
- **Green** — complete, reviewed, compliant

## Rules

- Every row must have a **Ref** and a **Requirement**. No orphan answers.
- Every **Mandatory** row must reach **Green** before submission — this is the
  hard check B05 (pre-flight) enforces.
- Split compound requirements into separate rows sharing the same Ref suffix
  (3.2.1a, 3.2.1b) so each is tracked independently.

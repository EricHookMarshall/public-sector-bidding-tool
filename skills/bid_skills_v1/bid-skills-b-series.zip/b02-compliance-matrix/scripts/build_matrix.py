#!/usr/bin/env python3
"""B02 — Compliance Matrix builder.

Writes a structured list of extracted requirements to a formatted .xlsx matrix.

The EXTRACTION (reading the tender and pulling requirements) is done by Claude
and passed in as structured data. This script only builds the workbook, so the
output format is deterministic and consistent across bids.

Usage:
    python build_matrix.py --in requirements.json --out matrix.xlsx --title "G-Cloud 15 Lot 3"

requirements.json = list of objects, each:
    {
      "ref": "3.2.1",            # source clause / question number (required)
      "requirement": "...",       # requirement text (required)
      "type": "M",                # M | D
      "response_type": "narrative",  # narrative|evidence|declaration|pricing
      "weighting": "10%",         # optional
      "limit": "500 words",       # optional response constraint
      "lot": "Lot 3",             # optional
      "owner": "",                # optional
      "rag": "Red",               # Red|Amber|Green (default Red)
      "evidence": "",             # source of FWF evidence, optional
      "notes": ""                 # optional
    }
"""
import argparse
import json
import sys

COLUMNS = [
    ("ref", "Ref"),
    ("requirement", "Requirement"),
    ("type", "M/D"),
    ("response_type", "Response type"),
    ("weighting", "Weighting"),
    ("limit", "Limit"),
    ("lot", "Lot"),
    ("owner", "Owner"),
    ("rag", "Status"),
    ("evidence", "Evidence source"),
    ("notes", "Notes"),
]

RAG_FILL = {"Red": "F4CCCC", "Amber": "FCE5CD", "Green": "D9EAD3"}


def build(reqs, out_path, title):
    try:
        from openpyxl import Workbook
        from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
        from openpyxl.utils import get_column_letter
    except ImportError:
        sys.exit("openpyxl not installed. Run: pip install openpyxl --break-system-packages")

    wb = Workbook()
    ws = wb.active
    ws.title = "Compliance Matrix"

    # Title row
    ws.cell(row=1, column=1, value=title).font = Font(bold=True, size=14)
    ws.merge_cells(start_row=1, start_column=1, end_row=1, end_column=len(COLUMNS))

    # Header row
    header_fill = PatternFill("solid", fgColor="1F2A44")
    thin = Side(style="thin", color="CCCCCC")
    border = Border(left=thin, right=thin, top=thin, bottom=thin)
    for c, (_, label) in enumerate(COLUMNS, start=1):
        cell = ws.cell(row=2, column=c, value=label)
        cell.font = Font(bold=True, color="FFFFFF")
        cell.fill = header_fill
        cell.alignment = Alignment(vertical="center", wrap_text=True)
        cell.border = border

    # Data rows
    for r, req in enumerate(reqs, start=3):
        rag = (req.get("rag") or "Red").capitalize()
        for c, (key, _) in enumerate(COLUMNS, start=1):
            val = req.get(key, "")
            cell = ws.cell(row=r, column=c, value=val)
            cell.alignment = Alignment(vertical="top", wrap_text=True)
            cell.border = border
        # colour the Status cell by RAG
        status_col = [k for k, _ in COLUMNS].index("rag") + 1
        if rag in RAG_FILL:
            ws.cell(row=r, column=status_col).fill = PatternFill("solid", fgColor=RAG_FILL[rag])

    # Column widths
    widths = {"Ref": 10, "Requirement": 60, "M/D": 6, "Response type": 14,
              "Weighting": 10, "Limit": 12, "Lot": 10, "Owner": 14,
              "Status": 10, "Evidence source": 24, "Notes": 24}
    for c, (_, label) in enumerate(COLUMNS, start=1):
        ws.column_dimensions[get_column_letter(c)].width = widths.get(label, 14)

    ws.freeze_panes = "A3"
    wb.save(out_path)
    return len(reqs)


def main():
    ap = argparse.ArgumentParser(description="Build a compliance matrix .xlsx")
    ap.add_argument("--in", dest="infile", required=True, help="requirements JSON")
    ap.add_argument("--out", required=True, help="output .xlsx path")
    ap.add_argument("--title", default="Compliance Matrix")
    args = ap.parse_args()

    with open(args.infile) as f:
        reqs = json.load(f)
    n = build(reqs, args.out, args.title)
    mandatory = sum(1 for r in reqs if (r.get("type") or "").upper() == "M")
    no_ev = sum(1 for r in reqs if not r.get("evidence"))
    print(f"Wrote {n} requirements to {args.out}")
    print(f"  Mandatory: {mandatory}   No evidence yet: {no_ev}")


if __name__ == "__main__":
    main()
